//CSCI 5607 HW 2 - Image Conversion Instructor: S. J. Guy <sjguy@umn.edu>
//In this assignment you will load and convert between various image formats.
//Additionally, you will manipulate the stored image data by quantizing, cropping, and suppressing channels

#include "image.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <random>
#include <chrono>

#include <fstream>
using namespace std;

/**
 * Image
 **/
Image::Image (int width_, int height_){

    assert(width_ > 0);
    assert(height_ > 0);

    width           = width_;
    height          = height_;
    num_pixels      = width * height;
    sampling_method = IMAGE_SAMPLING_POINT;
    
    data.raw = new uint8_t[num_pixels*4];
		int b = 0; //which byte to write to
		for (int j = 0; j < height; j++){
			for (int i = 0; i < width; i++){
				data.raw[b++] = 0;
				data.raw[b++] = 0;
				data.raw[b++] = 0;
				data.raw[b++] = 0;
			}
		}

    assert(data.raw != NULL);
}

Image::Image(const Image& src){
	width           = src.width;
	height          = src.height;
	num_pixels      = width * height;
	sampling_method = IMAGE_SAMPLING_POINT;
	
	data.raw = new uint8_t[num_pixels*sizeof(Pixel)];
	
	memcpy(data.raw, src.data.raw, num_pixels*sizeof(Pixel));
}

Image::Image(char* fname){

	int numComponents; //(e.g., Y, YA, RGB, or RGBA)

	//Load the pixels with STB Image Lib
	uint8_t* loadedPixels = stbi_load(fname, &width, &height, &numComponents, 4);
	if (loadedPixels == NULL){
		printf("Error loading image: %s", fname);
		exit(-1);
	}

	//Set image member variables
	num_pixels = width * height;
	sampling_method = IMAGE_SAMPLING_POINT;

  //Copy the loaded pixels into the image data structure
	data.raw = new uint8_t[num_pixels*sizeof(Pixel)];
	memcpy(data.raw, loadedPixels, num_pixels*sizeof(Pixel));
	free(loadedPixels);
}

Image::~Image(){
    delete[] data.raw;
    data.raw = NULL;
}

void Image::Write(char* fname){
	
	int lastc = strlen(fname);

	switch (fname[lastc-1]){
	   case 'g': //jpeg (or jpg) or png
	     if (fname[lastc-2] == 'p' || fname[lastc-2] == 'e') //jpeg or jpg
	        stbi_write_jpg(fname, width, height, 4, data.raw, 95);  //95% jpeg quality
	     else //png
	        stbi_write_png(fname, width, height, 4, data.raw, width*4);
	     break;
	   case 'a': //tga (targa)
	     stbi_write_tga(fname, width, height, 4, data.raw);
	     break;
	   case 'p': //bmp
	   default:
	     stbi_write_bmp(fname, width, height, 4, data.raw);
	}
}


void Image::Brighten (double factor){//since I changed the pixel class I had to change this
	double black = 0;
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel in_p = GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			//interpolate
			scaled_r = black + factor*(scaled_r-black);
			scaled_g = black + factor*(scaled_g-black);
			scaled_b = black + factor*(scaled_b-black);
			//clamp
			scaled_r = std::min(1.0, std::max(0.0, scaled_r));
			scaled_g = std::min(1.0, std::max(0.0, scaled_g));
			scaled_b = std::min(1.0, std::max(0.0, scaled_b));
			//scale back up to 255
			int new_r = static_cast<int>(std::floor(scaled_r*255));
			int new_g = static_cast<int>(std::floor(scaled_g*255));
			int new_b = static_cast<int>(std::floor(scaled_b*255));
			GetPixel(x,y) = Pixel(new_r,new_g,new_b);
		}
	}
}

void Image::ExtractChannel(int channel) {
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel* oneChannelP = new Pixel(0,0,0);
         if (channel == 0){oneChannelP->r=p.r;}
         else if (channel == 1){oneChannelP->g = p.g;}
         else{oneChannelP->b = p.b;}
			GetPixel(x,y) = *oneChannelP;
		}
	}
}


void Image::Quantize (int nbits){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel quantized_p = PixelQuant(p,nbits);
			GetPixel(x,y) = quantized_p;
		}
	}
}

Image* Image::Crop(int x0, int y0, int w, int h){
	Image* croppedImagePtr = new Image(w,h);
	int x,y;
	for (x = 0 ; x < w ; x++){
		for (y = 0 ; y < h ; y++){
			Pixel p = GetPixel(x+x0, y+y0);
			croppedImagePtr->GetPixel(x,y) = p;
		}
	}
	return croppedImagePtr;
}

Image* Image::Convolve(double** kernel, int kernel_size){
	const int radius = kernel_size / 2;
	Image* convolvedImgPtr = new Image(width,height);
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			double accumulated_r = 0.0;
			double accumulated_g = 0.0;
			double accumulated_b = 0.0;
			double kernel_sum = 0.0;
			//iterate over the kernel
			int kx,ky;
			for (kx=-radius; kx<=radius ; kx++){
				for(ky=-radius; ky<=radius ; ky++){
					double weight = kernel[kx+radius][ky+radius];
					int ix = x+kx;
					int iy = y+ky;

					//edge cases (handle with reflection)
					if(ix<0){ix = -ix-1;}
					if(iy<0){iy = -iy-1;}
					if(ix>=Width()){ix = Width() - 1-(ix-Width());}
					if(iy>=Height()){iy = Height() - 1-(iy-Height());}

					Pixel in_p = GetPixel(ix,iy);
					//to make things easier we will scale everything to be between 0 and 1
					double scaled_r = (double)in_p.r/255.0;
					double scaled_g = (double)in_p.g/255.0;
					double scaled_b = (double)in_p.b/255.0;
					accumulated_r = accumulated_r + (scaled_r*weight);
					accumulated_g = accumulated_g + (scaled_g*weight);
					accumulated_b = accumulated_b + (scaled_b*weight);
					kernel_sum += weight;
				}
			}
			if (kernel_sum > 0.0) {
				accumulated_r = accumulated_r/kernel_sum;
				accumulated_g = accumulated_g/kernel_sum;
				accumulated_b = accumulated_b/kernel_sum;           
			}
			//clamp
			accumulated_r = std::min(1.0, std::max(0.0, accumulated_r));
			accumulated_g = std::min(1.0, std::max(0.0, accumulated_g));
			accumulated_b = std::min(1.0, std::max(0.0, accumulated_b));
			//scale back up to 255
			int new_r = static_cast<int>(std::floor(accumulated_r*255));
			int new_g = static_cast<int>(std::floor(accumulated_g*255));
			int new_b = static_cast<int>(std::floor(accumulated_b*255));
			convolvedImgPtr->GetPixel(x,y) = Pixel(new_r,new_g,new_b);
		}
	}
	return convolvedImgPtr;
}


void Image::AddNoise (double factor){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel in_p = GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			//get random pixel value (i.e. purely noise image)
			Pixel random = PixelRandom();
			//to make things easier we will scale everything to be between 0 and 1
			double random_scaled_r = (double)random.r/255.0;
			double random_scaled_g = (double)random.g/255.0;
			double random_scaled_b = (double)random.b/255.0;
			//interpolate towards it by factor
			scaled_r = random_scaled_r + factor*(scaled_r-random_scaled_r);
			scaled_g = random_scaled_g + factor*(scaled_g-random_scaled_g);
			scaled_b = random_scaled_b + factor*(scaled_b-random_scaled_b);
			//clamp
			scaled_r = std::min(1.0, std::max(0.0, scaled_r));
			scaled_g = std::min(1.0, std::max(0.0, scaled_g));
			scaled_b = std::min(1.0, std::max(0.0, scaled_b));
			//scale back up to 255
			int new_r = static_cast<int>(std::floor(scaled_r*255));
			int new_g = static_cast<int>(std::floor(scaled_g*255));
			int new_b = static_cast<int>(std::floor(scaled_b*255));
			GetPixel(x,y) = Pixel(new_r,new_g,new_b);
		}
	}

}

void Image::ChangeContrast (double factor){
	double gray = .5;
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel in_p = GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			//interpolate
			scaled_r = gray + factor*(scaled_r-gray);
			scaled_g = gray + factor*(scaled_g-gray);
			scaled_b = gray + factor*(scaled_b-gray);
			//clamp
			scaled_r = std::min(1.0, std::max(0.0, scaled_r));
			scaled_g = std::min(1.0, std::max(0.0, scaled_g));
			scaled_b = std::min(1.0, std::max(0.0, scaled_b));
			//scale back up to 255
			int new_r = static_cast<int>(std::floor(scaled_r*255));
			int new_g = static_cast<int>(std::floor(scaled_g*255));
			int new_b = static_cast<int>(std::floor(scaled_b*255));
			GetPixel(x,y) = Pixel(new_r,new_g,new_b);
		}
	}
}


void Image::ChangeSaturation(double factor){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel in_p = GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			//get grayscale value of the pixel (luminance)
			double gray = (0.299 * scaled_r) + (0.587 * scaled_g) + (0.114 * scaled_b);
			//interpolate
			scaled_r = gray + factor*(scaled_r-gray);
			scaled_g = gray + factor*(scaled_g-gray);
			scaled_b = gray + factor*(scaled_b-gray);
			//clamp
			scaled_r = std::min(1.0, std::max(0.0, scaled_r));
			scaled_g = std::min(1.0, std::max(0.0, scaled_g));
			scaled_b = std::min(1.0, std::max(0.0, scaled_b));
			//scale back up to 255
			int new_r = static_cast<int>(std::floor(scaled_r*255));
			int new_g = static_cast<int>(std::floor(scaled_g*255));
			int new_b = static_cast<int>(std::floor(scaled_b*255));
			GetPixel(x,y) = Pixel(new_r,new_g,new_b);
		}
	}
}


//For full credit, check that your dithers aren't making the pictures systematically brighter or darker
void Image::RandomDither (int nbits){
	std::mt19937 generator(std::chrono::system_clock::now().time_since_epoch().count());
    std::uniform_int_distribution<int> distribution(0, 20); 
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x,y);
			Pixel in_p = GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			//find the threshold based on the index in the bayer matrix
			double threshold = distribution(generator) / (double)20;
			//see if values are in the threshold
			int out_r = (scaled_r > threshold) ? 255 : 0;
			int out_g = (scaled_g > threshold) ? 255 : 0;
			int out_b = (scaled_b > threshold) ? 255 : 0;

			GetPixel(x,y) = Pixel(out_r, out_g, out_b);
		}
	}
}

//This bayer method gives the quantization thresholds for an ordered dither.
//This is a 4x4 dither pattern, assumes the values are quantized to 16 levels.
//You can either expand this to a larger bayer pattern. Or (more likely), scale
//the threshold based on the target quantization levels.
static int Bayer4[4][4] ={
    {15,  7, 13,  5},
    { 3, 11,  1,  9},
    {12,  4, 14,  6},
    { 0,  8,  2, 10}
};

static double Gx[3][3] ={
    {-1,  0, +1},
    { -2, 0,  +2},
    {-1,  0, +1},
};

void Image::OrderedDither(int nbits){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x,y);
			Pixel in_p = GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			//find the threshold based on the index in the bayer matrix
			double threshold = Bayer4[x % 4][y % 4] / (double)16;
			//see if values are in the threshold
			int out_r = (scaled_r > threshold) ? 255 : 0;
			int out_g = (scaled_g > threshold) ? 255 : 0;
			int out_b = (scaled_b > threshold) ? 255 : 0;

			GetPixel(x,y) = Pixel(out_r, out_g, out_b);
		}
	}
}

/* Error-diffusion parameters */
const double
    ALPHA = 7.0 / 16.0,
    BETA  = 3.0 / 16.0,
    GAMMA = 5.0 / 16.0,
    DELTA = 1.0 / 16.0;

void Image::FloydSteinbergDither(int nbits){
	int x,y;
	for (y = 0 ; y < height ; y++){
		for (x = 0 ; x < width ; x++){
			Pixel p = GetPixel(x,y);
			Pixel quantized_p = PixelQuant(p,nbits);
			GetPixel(x,y) = quantized_p;
			double error_r = p.r-quantized_p.r;
			double error_g = p.g-quantized_p.g;
			double error_b = p.b-quantized_p.b;
			
			if (x + 1 < width) {
				double r = GetPixel(x + 1, y).r + error_r * ALPHA;
				double g = GetPixel(x + 1, y).g + error_g * ALPHA;
				double b = GetPixel(x + 1, y).b + error_b * ALPHA;
				GetPixel(x + 1, y) = Pixel(r,g,b);
            }
            
            // Neighbors on the next row (y+1)
            if (y + 1 < height) {
                
                // Neighbor (x-1, y+1) * (3/16)
                if (x - 1 >= 0) {
					double r = GetPixel(x - 1, y + 1).r + error_r * BETA;
					double g = GetPixel(x - 1, y + 1).g + error_g * BETA;
					double b = GetPixel(x - 1, y + 1).b + error_b * BETA;
					GetPixel(x - 1, y + 1) = Pixel(r,g,b);
                }
                
                // Neighbor (x, y+1) * (5/16)
				double r = GetPixel(x, y + 1).r + error_r * GAMMA;
				double g = GetPixel(x, y + 1).g + error_g * GAMMA;
				double b = GetPixel(x, y + 1).b + error_b * GAMMA;
				GetPixel(x, y + 1) = Pixel(r,g,b);
                
                // Neighbor (x+1, y+1) * (1/16)
                if (x + 1 < width) {
					double r = GetPixel(x + 1, y + 1).r + error_r * DELTA;
					double g = GetPixel(x + 1, y + 1).g + error_g * DELTA;
					double b = GetPixel(x + 1, y + 1).b + error_b * DELTA;
					GetPixel(x + 1, y + 1) = Pixel(r,g,b);
                }
            }
			
		}
	}
}

static double blurFilter[3][3] ={
    {1,1,1},
    {1,1,1},
    {1,1,1},
};

// Gaussian blur with size nxn filter
void Image::Blur(int n){
	double stdDev = ((double)n)/3.0;
	std::vector<double> gaussKernel(n*n);
	double sum = 0.0;
	int center = n / 2;

	//fill the kernel with values sampled from the gaussian function
	for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            double x = i - center;
            double y = j - center;
            double value = std::exp(-(x*x + y*y) / (2 * stdDev * stdDev));            
            gaussKernel[i * n + j] = value;
            sum += value;
        }
    }

    //make sure that all the values sum to 1
    for (int i = 0; i < n * n; ++i) {
        gaussKernel[i] /= sum;
    }
    
    double* blurFilterPtr[n];
    for (int i = 0; i < n; ++i) {
        blurFilterPtr[i] = &gaussKernel[i * n];
    }

	//this would do even blurring
	// double* blurFilterPtr[n];
	// double ones[n];
	// for (int j = 0; j < n; ++j) {
    //     ones[j] = 1;
    // }
    // for (int i = 0; i < n; ++i) {
    //     blurFilterPtr[i] = ones;
    // }
	
	Image* edges = Convolve(blurFilterPtr, n);
	for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            this->SetPixel(x, y, edges->GetPixel(x, y));
        }
    }
    delete edges;
}

void Image::Sharpen(int n){
	double factor = 3;
	double* blurFilterPtr[n];
	double ones[n];
	for (int j = 0; j < n; ++j) {
        ones[j] = 1;
    }
    for (int i = 0; i < n; ++i) {
        blurFilterPtr[i] = ones;
    }
	Image* blurredImgPtr = Convolve(blurFilterPtr, n);
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel in_p = GetPixel(x,y);
			Pixel blurred = blurredImgPtr->GetPixel(x,y);
			//to make things easier we will scale everything to be between 0 and 1
			double scaled_r = (double)in_p.r/255.0;
			double scaled_g = (double)in_p.g/255.0;
			double scaled_b = (double)in_p.b/255.0;
			double scaled_rbl = (double)blurred.r/255.0;
			double scaled_gbl = (double)blurred.g/255.0;
			double scaled_bbl = (double)blurred.b/255.0;
			//interpolate
			scaled_r = scaled_rbl + factor*(scaled_r-scaled_rbl);
			scaled_g = scaled_gbl + factor*(scaled_g-scaled_gbl);
			scaled_b = scaled_bbl + factor*(scaled_b-scaled_bbl);
			//clamp
			scaled_r = std::min(1.0, std::max(0.0, scaled_r));
			scaled_g = std::min(1.0, std::max(0.0, scaled_g));
			scaled_b = std::min(1.0, std::max(0.0, scaled_b));
			//scale back up to 255
			int new_r = static_cast<int>(std::floor(scaled_r*255));
			int new_g = static_cast<int>(std::floor(scaled_g*255));
			int new_b = static_cast<int>(std::floor(scaled_b*255));
			GetPixel(x,y) = Pixel(new_r,new_g,new_b);
		}
	}
}
// void Image::Sharpen(int n){}
// static double edgeFilter[3][3] ={
//     {-1,  0, +1},
//     { -2, 0,  +2},
//     {-1,  0, +1},
// };

static double edgeFilter[3][3] ={
    {-1,-1,-1},
    { -1,+8,-1},
    {-1,-1,-1},
};



// static double edgeFilter[3][3] ={
// 	    {0,0,0},
// 	    {0,1,0},
// 	    {0,0,0},
// 	};

void Image::EdgeDetect(){
	double* edgeFilterPtr[3];
    for (int i = 0; i < 3; ++i) {
        edgeFilterPtr[i] = edgeFilter[i];
    }
	Image* edges = Convolve(edgeFilterPtr, 3);
	for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            this->SetPixel(x, y, edges->GetPixel(x, y));
        }
    }
    delete edges;
}

Image* Image::Scale(double sx, double sy){
	//make new image at scaled heights and widths
	int w = width*sx;
	int h = height*sy;
	Image* scaledImagePtr = new Image(w,h);
	int x,y;
	for (x = 0 ; x < w ; x++){
		for (y = 0 ; y < h ; y++){//for each pizel index of the new image
			//scale to a number between 0 and 1
			float u = (double)x/(w-1.0);
			float v = (double)y/(h-1.0);
			Pixel p = Sample(u,v); //get the closest pixel at that spot in the original image
			scaledImagePtr->GetPixel(x,y) = p;
		}
	}
	return scaledImagePtr;
}

Image* Image::Rotate(double angle){
	double xCenter = (width - 1.0) / 2.0;
    double yCenter = (height - 1.0) / 2.0;
	Image* rotatedImagePtr = new Image(width,height);
	int x,y;
	for (x = 0 ; x < width ; x++){
		for (y = 0 ; y < height ; y++){
			//make the origin the center of the image so that we can properly use sin and cos
			double xTranslated = x - xCenter;
            double yTranslated = y - yCenter;
			double xOriginal = xTranslated*std::cos(-angle)-yTranslated*sin(-angle);
			double yOriginal = xTranslated*std::sin(-angle)+yTranslated*cos(-angle);
			//move back to positive coordinates where (0,0) is top left, and scale it to be a value between 0 and 1
			double u = (xOriginal+xCenter) / (width - 1.0);
			double v = (yOriginal+yCenter) / (height - 1.0);
			rotatedImagePtr->GetPixel(x,y) = Sample(u,v);
		}
	}
	return rotatedImagePtr;
	
}

void Image::Fun(){
	/* WORK HERE */
}

/**
 * Image Sample
 **/
void Image::SetSamplingMethod(int method){
   assert((method >= 0) && (method < IMAGE_N_SAMPLING_METHODS));
   sampling_method = method;
}

int Image::ReflectCoord(int coord, int size) {
    if (coord < 0) { //reflect left edges to the right
        return -coord - 1; 
    } else if (coord >= size) { //reflect right edges to the left
        return size - 1 - (coord - (size - 1));
    }
    return coord; // Coord is already valid
}

//expects a u and v in the range of 0,1
Pixel Image::Sample (double u, double v){
   if (sampling_method == IMAGE_SAMPLING_POINT){ //nearest neighbor
	double xScaled = u*(width-1); //scale up to the image size from a u in 0,1
	double yScaled = v * (height - 1.0);

	//get integer value
	int xInt = static_cast<int>(std::round(xScaled));
	int yInt = static_cast<int>(std::round(yScaled));
	
	// // 2. Clamp the integer indices to the valid range [0, width-1]
	// // This makes an explicit external ValidCoord check unnecessary for [0, 1] inputs.
	// x_int = std::min(std::max(0, x_int), width - 1);
	// y_int = std::min(std::max(0, y_int), height - 1);

	//clamping assures we always have a valid coordinate, but sometimes we want to know something informational instead of a pixel if its not a valid coordinate
	if (!ValidCoord(xInt,yInt)){
		return Pixel(1,0,0);
	}
	return GetPixel(xInt,yInt);
   }else if(sampling_method==IMAGE_SAMPLING_BILINEAR){
	double xScaled = u*(width-1); //scale up to the image size from a u in 0,1
	double yScaled = v * (height - 1.0);
	//get integer value in the dimensions of the image
	int x0 = static_cast<int>(std::floor(xScaled));
	int y0 = static_cast<int>(std::floor(yScaled));
	int x1 = x0+1;
	int y1 = y0+1;

	double dx = xScaled - x0; // weight for x1
    double dy = yScaled - y0; // weight for y1
    
	//edge cases, handle with reflection
	x0 = ReflectCoord(x0, width);
    y0 = ReflectCoord(y0, height);
    x1 = ReflectCoord(x1, width);
    y1 = ReflectCoord(y1, height);
	
	Pixel top_interp = PixelLerp(GetPixel(x0,y0),GetPixel(x1,y0),dx);
	Pixel bottom_interp = PixelLerp(GetPixel(x0,y1),GetPixel(x1,y1),dx);
	return PixelLerp(top_interp,bottom_interp,dy);

   }else if(sampling_method==IMAGE_SAMPLING_GAUSSIAN){
	//get all nearby pixels
	//return the gaussian weighted average
   }
   return Pixel();
}